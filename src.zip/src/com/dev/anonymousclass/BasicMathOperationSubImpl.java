package com.dev.anonymousclass;

public class BasicMathOperationSubImpl implements BasicMathOperation {

	@Override
	public int operation(int num1, int num2) {
		return num1 - num2;
	}
}
