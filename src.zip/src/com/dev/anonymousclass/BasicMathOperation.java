package com.dev.anonymousclass;

/**
 * Abstraction
 * @author 91967
 *
 */

public interface BasicMathOperation {
	public int operation(int num1,int num2);
}
