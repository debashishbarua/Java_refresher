package com.dev.anonymousclass.alt;

public class CalculatorTest {	
	
	public interface BasicMathOperation {
		public int operation(int num1,int num2);
	}


	public static void main(String[] args) {
		
		
		BasicMathOperation bo=null;
		//Anonymous Implementation
		bo=new BasicMathOperation() {
			@Override
			public int operation(int num1, int num2) {				
				return num1 +num2;
			}				
		};
		
		System.out.println(bo.operation(10, 10));
		bo=new BasicMathOperation() {
			@Override
			public int operation(int num1, int num2) {				
				return num1 - num2;
			}				
		};		
		System.out.println(bo.operation(10, 10));

	}

}
