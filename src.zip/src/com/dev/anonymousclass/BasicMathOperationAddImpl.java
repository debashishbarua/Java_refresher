package com.dev.anonymousclass;

/**
 * Client class/Implemented Class
 * 
 * @author 91967
 *
 */
public class BasicMathOperationAddImpl implements BasicMathOperation {

	@Override
	public int operation(int num1, int num2) {

		return num1 + num2;
	}
}
