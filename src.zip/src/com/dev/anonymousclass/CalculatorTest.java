package com.dev.anonymousclass;

public class CalculatorTest {	

	public static void main(String[] args) {
	
		BasicMathOperation bo=null;
		
		bo=new BasicMathOperationAddImpl();
		System.out.println(bo.operation(10, 10));
		
		bo = new BasicMathOperationSubImpl();
		System.out.println(bo.operation(10, 10));

	}

}
