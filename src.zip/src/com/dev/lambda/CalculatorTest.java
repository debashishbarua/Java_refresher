package com.dev.lambda;

public class CalculatorTest{		


	public static void main(String[] args) {
		
		
		BasicMathOperation bo=null;
		//Lambda
		bo= (int a,int b) -> { return a+b;};		
		System.out.println(bo.operation(10, 10));
		
		
		bo=(a,b) -> { return a-b;};		
		System.out.println(bo.operation(10, 10));
		
		bo=(a,b) ->  a-b;		
		System.out.println(bo.operation(10, 10));

	}

}
