package com.dev.lambda.existingfunction.example;

@FunctionalInterface
public  interface CheckPerson{
	 public boolean tester(Person person);
}