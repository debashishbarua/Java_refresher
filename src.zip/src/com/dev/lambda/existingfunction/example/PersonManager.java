package com.dev.lambda.existingfunction.example;

import java.util.List;

public class PersonManager {
	
	
	// 3. Get all the person age more than 30
	 //Anonymous Inner class
	 public static void printPersonOlderThanUsingImplClass(List<Person> persons, CheckPerson checkPerson) {
			for (Person p : persons) {
				if (checkPerson.tester(p))
					p.printPerson();
			}
	 }	 
	 
	
//
//	// 1. Get all the person age more than 30
//
//	public static void printPersonOlderThan(List<Person> persons, int age) {
//		for (Person p : persons) {
//			if (p.getAge() >= age)
//				p.printPerson();
//		}
//	}
//
//	// 2. Get all the person age between low and high
//
//	public static void printPersonByAgeBetween(List<Person> persons, int low, int high) {
//		for (Person p : persons) {
//			if (p.getAge() >= low && p.getAge() <= high)
//				p.printPerson();
//		}
//	}

	

}
