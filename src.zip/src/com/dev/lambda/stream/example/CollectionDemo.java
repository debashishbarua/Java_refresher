package com.dev.lambda.stream.example;

import java.util.List;
import java.util.OptionalDouble;

public class CollectionDemo {

	public static void main(String[] args) {

		List<Person> persons = Person.createRoster();
		
		
		persons.stream()
		.filter(p -> p.getAge()<30)
		.forEach(person -> person.printPerson());
		
		double averageSal=persons.stream()
				.mapToDouble(p -> p.getSalary())
				.average()
				.getAsDouble();
		System.out.println(averageSal);
		
		//What is Optional in java
		
		OptionalDouble averageSal1=persons.stream()
				.mapToDouble(p -> p.getSalary())
				.average();
				
		System.out.println(averageSal);
		
//		persons.forEach(person -> System.out.println(person.getEmailAddress()));
//		System.out.println();
		
//		for (Person person : persons) {
//			System.out.println(person.getEmailAddress());
//		}
		
//		persons.forEach(p -> p.printPerson());
//		System.out.println();
//		for (Person person : persons) {
//			person.printPerson();
//		}

//		for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
//			iterator.next().printPerson();
//		}

//		for (int i = 0; i < persons.size(); i++) {
//			persons.get(i).printPerson();
//		}

	}

}
