package com.dev.lambda.example;

import java.util.ArrayList;
import java.util.List;
public class PersonApplication {

	public static void main(String[] args) {
		List<Person> persons = Person.createRoster();
		// Printing all person
		for (Person p : persons) {
			p.printPerson();
		}
		
		System.out.println();
		PersonManager.processPersonsWithFunction(
				persons,  
				p -> p.getAge() >= 30,
				p -> p.getName(),
				name -> System.out.println(name.toUpperCase())
			);
		
		System.out.println();
		PersonManager.processElements(
				persons,  
				p -> p.getAge() >= 30,
				p -> p.getName(),
				name -> System.out.println(name.toUpperCase())
			);
		
		
		
		
//		// Lambda
//		Predicate<Person> predicate = person -> person.getAge() >= 30;
//		PersonManager.processPerson(persons, predicate);
//		System.out.println();		
//		
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30);
//		System.out.println();
//		
//		Consumer<Person> consumer= p -> System.out.println(p.getEmailAddress());
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30,consumer );
//		System.out.println();
//		
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30,p -> System.out.println(p.getEmailAddress()) );
//		System.out.println();
//		
//		class ConsumerImpl implements Consumer<Person>{
//
//			@Override
//			public void accept(Person p) {				
//				System.out.println(p.getAge());
//			}
//			
//		}
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30, new ConsumerImpl() );
//		
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30, new Consumer<Person>() {
//			@Override
//			public void accept(Person p) {				
//				System.out.println(p.getAge());
//			}
//		});
//		
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30,			
//			(Person p) ->{				
//				System.out.println(p.getAge());
//			}
//		);
//		PersonManager.processPerson(persons,  person -> person.getAge() >= 30,	p ->System.out.println(p.getAge()));
	}

}
