package com.dev.lambda.example;

import java.util.List;

public class PersonApplication {

	public static void main(String[] args) {
		List<Person> persons = Person.createRoster();
		// Printing all person
//			for (Person p : persons) {
//				p.printPerson();
//			}
		// Implemented class
		// Local Class
//		class CheckEligiblePerson implements CheckPerson {
//			@Override
//			public boolean tester(Person person) {
//				return person.getAge() >= 30;
//			}
//		}
//		PersonManager.printPersonOlderThanUsingImplClass(persons, new CheckEligiblePerson());
//		System.out.println();
//		// Anonymous Inner class
//		PersonManager.printPersonOlderThanUsingImplClass(persons, new CheckPerson() {
//			@Override
//			public boolean tester(Person person) {
//				return person.getAge() >= 30;
//			}
//		});
//		System.out.println();
//		//Lambda 
//		CheckPerson checkPerson= person -> person.getAge() >= 30;
//		PersonManager.printPersonOlderThanUsingImplClass(persons, checkPerson);
//		System.out.println();
		
		//Lambda 
		PersonManager.printPersonOlderThanUsingImplClass(persons, person -> person.getAge() >= 30);
		System.out.println();
		
		PersonManager.printPersonOlderThanUsingImplClass(persons, person -> person.getName().equals("Fred"));
		System.out.println();
		// printPersonOlderThan
		// printPersonOlderThan(persons, 30);
		// System.out.println();
	}

}
