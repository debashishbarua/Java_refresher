package com.dev.lambda.example;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class PersonManager {
	
	
	 public static void processPerson(List<Person> persons, Predicate<Person> predicate) {
			for (Person p : persons) {
				if (predicate.test(p))
					p.printPerson();
			}
	 }	 
	 
	 public static void processPerson(List<Person> persons, Predicate<Person> predicate, Consumer<Person> consumer) {
			for (Person p : persons) {
				if (predicate.test(p))
					consumer.accept(p);
			}
	 }	

	 public static void processPersonsWithFunction(
			 List<Person> persons, 
			 Predicate<Person> tester,
			 Function<Person, String> mapper, 
			 Consumer<String> block) {
			for (Person p : persons) {
				if (tester.test(p)) {
					String name = mapper.apply(p);
					block.accept(name);
				}
			}
	 }
	 //Generic
	 public static <X, Y> void processElements(
			 Iterable<X> source, 
			 Predicate<X> tester, 
			 Function<X, Y> mapper,	
			 Consumer<Y> block) {
			for (X p : source) {
				if (tester.test(p)) {
					Y data = mapper.apply(p);
					block.accept(data);
				}
			}
		}

}









