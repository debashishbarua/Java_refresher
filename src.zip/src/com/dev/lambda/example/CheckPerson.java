package com.dev.lambda.example;

public  interface CheckPerson{
	 public boolean tester(Person person);
}