package com.dev.lambda;
/**
 * Functional Interface
 * @author 91967
 *
 */

@FunctionalInterface
public interface BasicMathOperation {
	public int operation(int num1,int num2);
}