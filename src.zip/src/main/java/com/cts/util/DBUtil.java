package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private static Connection connection = null;

	private final static String USERNAME = "root";
	private final static String PASSWORD = "mysql";
	private final static String JDBCURL = "jdbc:mysql://localhost:3306/java_refresh_db";
	private final static String DRIVER_CLASS = "";

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection(JDBCURL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			System.err.println("Error: " + e.getMessage());			
		}
		return connection;

	}
}
