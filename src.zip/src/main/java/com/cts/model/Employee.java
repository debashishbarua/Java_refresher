package com.cts.model;

public class Employee {

	public static int count = 0;

	private int id;
	private String name;
	private String currentProject;

	/**
	 * Parameterised Costructor
	 * @param id
	 * @param name
	 */
	public Employee(int id, String name) {
		Employee.count++;
		this.id = id;
		this.name = name;
	}

	// Setter

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCurrentProject(String currentProject) {
		this.currentProject = currentProject;
	}

	// Getter
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getCurrentProject() {
		return currentProject;
	}

	@Override
	public String toString() {
		return id + "  " + name + "  " + currentProject;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currentProject == null) ? 0 : currentProject.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (currentProject == null) {
			if (other.currentProject != null)
				return false;
		} else if (!currentProject.equals(other.currentProject))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
