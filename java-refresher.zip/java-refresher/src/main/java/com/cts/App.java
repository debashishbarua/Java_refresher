package com.cts;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import com.cts.dao.EmployeeDao;
import com.cts.dao.EmployeeDaoImplCollection;
import com.cts.dao.EmployeeDaoImplJDBC;
import com.cts.model.Employee;
import com.cts.util.DBUtil;

/**
 * Hello world!
 *
 */
public class App {

	public static void main(String[] args) {
		//DBUtil dbUtil=new DBUtil();		
		//System.out.println(dbUtil.getConnection());
		//System.out.println(DBUtil.getConnection());
		
		//For Insert 
		
		EmployeeDao dao=new EmployeeDaoImplJDBC();
		
		Employee employee=new Employee(200, "Akash");
		employee.setCurrentProject("currentProject");
		
		try {
			dao.addEmployee(employee);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}
	/*
	 * private static EmployeeDao employeeDao = new EmployeeDaoImplCollection();
	 * 
	 * public static void main(String[] args) {
	 * 
	 * employeeDao.addEmployee(new Employee(101, "Akash"));
	 * 
	 * employeeDao.addEmployee(new Employee(121, "Ankit"));
	 * 
	 * List<Employee> employees = employeeDao.getEmployees();
	 * 
	 * // for (Iterator<Employee> iterator = employees.iterator();
	 * iterator.hasNext();) { // Employee employee = iterator.next(); //
	 * System.out.println(employee); // }
	 * 
	 * // Prints the employee // for (int i = 0; i < employees.size(); i++) { //
	 * System.out.println(employees.get(i)); // }
	 * 
	 * for (Employee e : employees) { System.out.println(e); }
	 * System.out.println("After Delete"); employeeDao.deleteEmployee(121);
	 * employees = employeeDao.getEmployees(); for (Employee e : employees) {
	 * System.out.println(e); }
	 * 
	 * }
	 */

	/*
	 * Example 1 public static void main(String[] args) {
	 * System.out.println(Employee.count);
	 * 
	 * Employee e1 = new Employee(10, "Garima");// Creating a employee
	 * 
	 * e1.setCurrentProject("Employee MGMT");
	 * 
	 * System.out.println(e1); Employee e2 = new Employee(11, "Garima");// Creating
	 * a employee System.out.println(Employee.count);
	 * 
	 * }
	 */
}
