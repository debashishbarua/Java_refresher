package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cts.model.Employee;
import com.cts.util.DBUtil;

public class EmployeeDaoImplJDBC  implements EmployeeDao{
	private static final String INSERT_SQL="insert into employee(id, employee_name, current_project)  values(?,?,?)";

	/**
	 * Inserting Record to data base
	 * @throws SQLException 
	 */
	public void addEmployee(Employee employee) throws SQLException {
		
		
		//Connection
		Connection connection=DBUtil.getConnection();		
		//Create statement		
		PreparedStatement ps=connection.prepareStatement(INSERT_SQL);
		//Set Parameters
		ps.setInt(1, employee.getId());
		ps.setString(2, employee.getName());
		ps.setString(3, employee.getCurrentProject());
		//Execute the statement	
		int res=ps.executeUpdate();
		
	}

	public void updateEmployee(Employee employee) {
		
		
	}

	public void deleteEmployee(int id) {
		
		
	}

	public List<Employee> getEmployees() {
	
		return null;
	}

	public Employee getEmployeeById(int id) {
		
		return null;
	}

}
