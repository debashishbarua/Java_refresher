package com.cts.dao;

import java.sql.SQLException;
import java.util.List;

import com.cts.model.Employee;

public interface EmployeeDao {
	
	public void addEmployee(Employee employee) throws SQLException;
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int id);
	public List<Employee> getEmployees();
	public Employee getEmployeeById(int id);
	
}
