package com.cts.dao;

import java.util.ArrayList;
import java.util.List;

import com.cts.model.Employee;

public class EmployeeDaoImplCollection implements EmployeeDao {
	
	private  List<Employee> EMPLOYEES=new ArrayList<Employee>();

	public void addEmployee(Employee employee) {
		
		EMPLOYEES.add(employee);
	}

	public void updateEmployee(Employee employee) {

	}

	public void deleteEmployee(int id) {
		List<Employee> emp=new ArrayList<Employee>();
		for (Employee employee : EMPLOYEES) {
			if(employee.getId() != id) {
				emp.add(employee);
			}
		}
		EMPLOYEES =emp;

	}

	public List<Employee> getEmployees() {

		return EMPLOYEES;
	}

	public Employee getEmployeeById(int id) {

		return null;
	}

}
