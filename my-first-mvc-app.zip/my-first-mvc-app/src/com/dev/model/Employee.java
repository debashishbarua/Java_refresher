package com.dev.model;

public class Employee {

}
