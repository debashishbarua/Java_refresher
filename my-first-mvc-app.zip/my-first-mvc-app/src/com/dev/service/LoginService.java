package com.dev.service;

import com.dev.model.User;

public interface LoginService {

	boolean isValid(User user);

}