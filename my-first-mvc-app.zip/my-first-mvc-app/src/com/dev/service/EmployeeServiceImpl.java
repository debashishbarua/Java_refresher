package com.dev.service;

import java.sql.SQLException;
import java.util.List;

import com.dev.dao.EmployeeDao;
import com.dev.dao.EmployeeDaoImpl;
import com.dev.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao dao = new EmployeeDaoImpl();

	@Override
	public List<Employee> findAllEmployees() throws SQLException {

		return dao.findAllEmployees();
	}

}
