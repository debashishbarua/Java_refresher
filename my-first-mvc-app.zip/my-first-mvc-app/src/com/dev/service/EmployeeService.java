package com.dev.service;

import java.sql.SQLException;
import java.util.List;

import com.dev.model.Employee;

public interface EmployeeService {
	
	public abstract List<Employee> findAllEmployees() throws SQLException;

}
