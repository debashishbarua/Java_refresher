package com.dev.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dev.model.Employee;
import com.dev.service.EmployeeService;
import com.dev.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private EmployeeService service = new EmployeeServiceImpl();
	 

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeController() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);

	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		System.out.println("Action: " + action);
		if (action.equals("displayAll")) {
			displayAllEmployees(request, response);
		} else if (action.equals("createNewEmployee")) {

		} else {

		}
	}

	private void displayAllEmployees(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd =null;
		try {
			List<Employee> employees = service.findAllEmployees();
			//System.out.println("Employees: " + employees);
			//Render The response and data to the employees.jsp page
			rd=request.getRequestDispatcher("employees.jsp");
			request.setAttribute("employees", employees);
			rd.forward(request, response);
		} catch (SQLException e) {
			// Log 
			e.printStackTrace();
		}
		
	}
}
