package com.dev.dao;

public interface UserDao {

}
