package com.dev.dao;

import java.sql.SQLException;
import java.util.List;

import com.dev.model.Employee;

public interface EmployeeDao {
	public abstract List<Employee> findAllEmployees() throws SQLException;
}
