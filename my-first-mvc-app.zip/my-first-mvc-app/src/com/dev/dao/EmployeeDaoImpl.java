package com.dev.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dev.model.Employee;
import com.dev.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	private static final String SQL_SELECT_ALL = "select * from employee";

	/**
	 * Used for returing all record of employee from data base
	 */
	public List<Employee> findAllEmployees() throws SQLException {

		List<Employee> employees = new ArrayList<Employee>();

		Connection connection = DBUtil.getConnection();

		PreparedStatement ps = connection.prepareStatement(SQL_SELECT_ALL);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			// Create The Employee Object
			Employee employee = new Employee(rs.getInt("employee_id"), rs.getString("first_name"),
					rs.getString("first_name"), rs.getDate("date_of_birth"), rs.getDate("date_of_Join"),
					rs.getDouble("salary"));

			// Add to Employee list objcet
			employees.add(employee);

		}
		
		return employees;
	}

}
