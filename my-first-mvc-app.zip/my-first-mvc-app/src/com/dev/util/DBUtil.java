package com.dev.util;

public class DBUtil {

}
