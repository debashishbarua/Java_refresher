package com.dev.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Used for creation of javax.sql.Connection object
 * 
 * @author Debashish Barua
 *
 */
public class DBUtil {

	/**
	 * Used for store the database connection
	 */
	private static Connection connection = null;

	private final static String USERNAME = "root";
	private final static String PASSWORD = "mysql";
	private final static String JDBCURL = "jdbc:mysql://localhost:3306/test";
	private final static String DRIVERCLASS ="com.mysql.cj.jdbc.Driver";

	/**
	 * Used for returning the Connection Object
	 * 
	 * @return java.sql.Connection Object
	 */
	public static Connection getConnection() {
		try {
			//Load the Driver Class
			Class.forName(DRIVERCLASS);
			connection = DriverManager.getConnection(JDBCURL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			System.err.println("Error: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

}
